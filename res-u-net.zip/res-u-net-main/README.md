https://github.com/nikhilroxtomar/Deep-Residual-Unet/blob/master/Deep%20Residual%20UNet.ipynb
https://kartographie.geo.tu-dresden.de/downloads/ica-gen/publications/savino.pdf
Road Extraction by Deep Residual U-Net : https://arxiv.org/pdf/1711.10684.pdf